<?php
$hashed_password = password_hash('19283756401Bz1819EE', PASSWORD_DEFAULT);
echo $hashed_password;
?>
