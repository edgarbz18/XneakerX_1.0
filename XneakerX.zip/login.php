<form action="controlador.php" method="POST">

    <label for="username">Usuario:</label>
    <input type="text" id="username" name="username" required>
    
    <label for="password">Contraseña:</label>
    <input type="password" id="password" name="password" required>
    
    <button type="submit">Iniciar Sesión</button>
</form>
